package hw2;

import java.util.Stack;

public class SentenceBuilder {
	private ContextFreeLanguage cfl = null;
	private boolean printingLog = false;

	public SentenceBuilder(ContextFreeLanguage cfl) {
		super();
		this.cfl = cfl;
		this.printingLog = cfl.isPrintingLog();
	}
	public String buildSentence() {
		
		Stack<IntermediateSentence> stack = new Stack<IntermediateSentence>();
		IntermediateSentence startSymbol = new IntermediateSentence(cfl);

		// printing log
		if (this.printingLog) {
                        System.out.println("##########################");
			System.out.println("Starting Building Sentence:");
			System.out.println("Selected Start Symbol");
                        System.out.println("##########################");
			startSymbol.printLog();
		}
		// end

		stack.push(startSymbol);

		IntermediateSentence is = null;
		while (!stack.empty()) {
			is = stack.peek();

			// printing log
			if (this.printingLog) {
                                System.out.println("###################");
				System.out.println("Current Sentence:");
                                System.out.println("###################");
				is.printLog();
			}
			// end

			if (is.qualified()) {
				// return the found sentence
				return is.getBuiltSentence();
			}
			if (is.needBackOff()) {
				// need back off
				stack.pop();
			} else {
				is = new IntermediateSentence(is);
				stack.push(is);
			}
		}
		return null;
	}
}
