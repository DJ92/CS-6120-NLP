package hw2;

import java.util.Random;

class RandomNumberGenerator {
	
	public static int randomIntTo(int to){
		try {
			Thread.sleep(3);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Random generator = new Random(System.currentTimeMillis());
		int rand = Math.abs(generator.nextInt());
		return rand % to;
	}
}
