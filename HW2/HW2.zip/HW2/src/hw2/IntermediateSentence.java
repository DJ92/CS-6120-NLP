package hw2;

import java.util.ArrayList;
import java.util.LinkedList;

public class IntermediateSentence {
	private LinkedList<String> sentence = null;
	private LinkedList<Rule> rules = null;
	private ContextFreeLanguage cfl = null;

	public IntermediateSentence(ContextFreeLanguage cfl) {
		this.cfl = cfl;
		ArrayList<Rule> startSymbolRules = cfl.getMapping().get("START");
		this.rules = new LinkedList<Rule>(startSymbolRules);
		Rule selectedStartRule = randomSelectRule();
		String startSymbol = selectedStartRule.getToSymbols().get(0);
		this.sentence = new LinkedList<String>();
		sentence.add(startSymbol);
		ArrayList<Rule> allRules = this.cfl.getMapping().get(startSymbol);
		this.rules = new LinkedList<>(allRules);
	}

	
	public IntermediateSentence(IntermediateSentence is) {
		//Copy Attributes
		this.cfl = is.cfl;
		this.sentence = new LinkedList<String>(is.sentence);
		//Randomly Select
		Rule selectedRule = is.randomSelectRule();
		String fromSymbol = selectedRule.getFromSymbol();
		ArrayList<String> toSymbols = selectedRule.getToSymbols();
		//Remove the Selected Rule
		is.rules.remove(selectedRule);
		//Modify Sentence
		int index = this.sentence.indexOf(fromSymbol);
		this.sentence.remove(fromSymbol);
		this.sentence.addAll(index, toSymbols);
		//First Non Terminals
		String firstNonTerminal = null;
		for (String symbol : this.sentence) {
			if (isNonTerminal(symbol)) {
				firstNonTerminal = symbol;
				break;
			}
		}

		if (firstNonTerminal == null) {
			//Terminal Symbols
			this.rules = new LinkedList<Rule>();
		} else {
			//Get Rules
			ArrayList<Rule> allRules = this.cfl.getMapping().get(
					firstNonTerminal);
			this.rules = new LinkedList<Rule>(allRules);
		}
	}

	private boolean isNonTerminal(String symbol) {
		return this.cfl.getNonTerminalSymbols().contains(symbol);
	}

	public Rule randomSelectRule() {
		int totalRuleWeight = 0;
		for (Rule rule : this.rules) {
			totalRuleWeight += rule.getWeight();
		}
		int randomInt = RandomNumberGenerator.randomIntTo(totalRuleWeight);
		int accmulatedWeight = 0;
		for (Rule rule : this.rules) {
			if (accmulatedWeight <= randomInt
					&& randomInt < (accmulatedWeight + rule.getWeight())) {
				//Select Rule
				return rule;
			} else {
				accmulatedWeight += rule.getWeight();
			}
		}
		return null;
	}

	public boolean needBackOffForSentenceOfLength(int sentenceLength) {
		if (this.sentence.size() > sentenceLength) {
			// when length of sentence is longer than given
			return true;
		} else if (this.rules.size() == 0) {
			// no remain rule to try
			return true;
		}
		return false;
	}

	public boolean qualifiedForSentenceOfLength(int sentenceLength) {
		if (this.sentence.size() == sentenceLength) {
			// length of this sentence is qualified
			boolean allSymbolsAreTerminal = true;
			for (String symbols : this.sentence) {
				allSymbolsAreTerminal = allSymbolsAreTerminal
						&& this.cfl.getTerminalSymbols().contains(symbols);
			}
			return allSymbolsAreTerminal;
		} else {
			return false;
		}
	}

	public boolean needBackOff() {
		if (this.rules.size() == 0) {
			// no remain rule to try
			return true;
		}
		return false;
	}

	public boolean qualified() {
		boolean allSymbolsAreTerminal = true;
		for (String symbols : this.sentence) {
			allSymbolsAreTerminal = allSymbolsAreTerminal
					&& this.cfl.getTerminalSymbols().contains(symbols);
		}
		return allSymbolsAreTerminal;
	}

	public String getBuiltSentence() {
		String concatenated = "";
		for (String str : this.sentence) {
			concatenated = concatenated + str + " ";
		}
		return concatenated;
	}

	public void printLog() {
		System.out.println("==========");
		String concatenated = "[ ";
		for (String str : this.sentence) {
			concatenated = concatenated + str + " ";
		}
		concatenated += "]";
                System.out.println("####################");
		System.out.println("Sentence: ");
                System.out.println("####################");
		System.out.println(concatenated);
                System.out.println("####################");
		System.out.println("Remaining rules: ");
                System.out.println("####################");
		for (Rule rule : this.rules) {
			System.out.println("\t" + rule.toString());
		}
		System.out.println("                   ");
		System.out.println();
	}
}
