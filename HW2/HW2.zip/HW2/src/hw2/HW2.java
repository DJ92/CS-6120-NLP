package hw2;

import java.io.*;
import java.util.ArrayList;

public class HW2 {
	public static void main(String[] args) {
		
		try{
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                System.out.println("#########################################");
                System.out.println("Enter the file consisting of grammar: ");
                System.out.println("#########################################");
                String path = br.readLine();
		ContextFreeLanguage cfl = new ContextFreeLanguage(path, true);
		SentenceBuilder sb = new SentenceBuilder(cfl);
                
                System.out.println("#########################################");
                System.out.println("Enter the number of sentences to print: ");
                System.out.println("#########################################");
		int number = Integer.parseInt(br.readLine());
                ArrayList<String> generatedStrs = new ArrayList<String>();
		for (int i = 0;i < number; i++){
			generatedStrs.add(sb.buildSentence());
		}
		
		for (String string : generatedStrs) {
			System.out.println(string);
		}
		
		double totalLength = 0;
		for (String string : generatedStrs) {
			String[] sa = string.split(" ");
			totalLength += sa.length;
		}
		
		if (true){
                        System.out.println("####################");
			System.out.println("Average length: " + (totalLength/number));
                        System.out.println("####################");
		}
                }
                catch(Exception e){
                    System.out.println("Input Error");
                }
		
	}
}
