__author__ = 'DJ'

import string
import speech_recognition as sr
import nltk as nt
import unicodedata
r = sr.Recognizer()
with sr.Microphone() as source:
    audio = r.listen(source)
text = ""
try:
    print("You said : " + r.recognize_google(audio))
    text = str(r.recognize_google(audio))
except LookupError:
    print("Could not understand audio")
text111 = nt.word_tokenize(text,language='english')
print(nt.pos_tag(text111))