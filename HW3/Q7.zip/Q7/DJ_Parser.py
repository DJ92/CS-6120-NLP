__author__ = 'DJ'

# Bracketing Transduction Grammar Parser has been implemented

# Global variables:

DELTA = None      # matrix for storing the probabilities
THETA = None      # matrix for storing the forward or inverse
PHI_SB = None     # store the argmax for j [square bracket]
KAPPA_SB = None    # store the argmax for k [square bracket]
SIGMA_SB = None    # store the argmax of s [square bracket]
EPSILON_SB = None  # store the argmax of u [square bracket]
PHI_AB = None     # store the argmax for j [ankle bracket]
KAPPA_AB = None    # store the argmax for k [ankle bracket]
SIGMA_AB = None    # store the argmax of s [ankle bracket]
EPSILON_AB = None  # store the argmax of u [ankle bracket]
NODES = []        # array of NODES
countSB = 0       # count of square brackets []
countAB = 0       # count of ankle brackets <>
countEToWord = 0       # count of <e>-word align
countWordToE = 0       # count of word-<e> align
countWordToWord = 0    # count of word-word align

# Lexical dictionary
class LexicalDictionary:
    entries = []
    def __init__(self,lines):
        for line in lines:
            entry = line.split('\t')
            self.entries.append(entry)

    def b(self,lang1word,lang2word):
        for entry in self.entries:
            if entry[0] == lang1word and entry[1] == lang2word:
                return float(entry[2])

        return float('-inf')

# BTG Grammar
class BTGGrammar:
    def __init__(self,sb,ab,epw,wep):
        self.aToSb = sb
        self.aToAb = ab
        self.epsilonWord = epw
        self.wordEpsilon = wep

# Parse function
def parse(sent1,sent2,grammar,lexical):
    global DELTA
    global THETA
    global PHI_SB
    global KAPPA_SB
    global SIGMA_SB
    global EPSILON_SB
    global PHI_AB
    global KAPPA_AB
    global SIGMA_AB
    global EPSILON_AB
    global NODES
    global countSB
    global countAB
    global countEToWord
    global countWordToE
    global countWordToWord

    T = len(sent1)
    V = len(sent2)
    NODES = []
    DELTA = [[[[None
                for x1 in range(0,V+1)]
               for x2 in range(0,V+1)]
              for x3 in range(0,T+1)]
             for x4 in range(0,T+1)]
    THETA =  [[[[''
                for x1 in range(0,V+1)]
               for x2 in range(0,V+1)]
              for x3 in range(0,T+1)]
             for x4 in range(0,T+1)]
    PHI_SB =  [[[['A'
                for x1 in range(0,V+1)]
               for x2 in range(0,V+1)]
              for x3 in range(0,T+1)]
             for x4 in range(0,T+1)]
    KAPPA_SB =  [[[['A'
                for x1 in range(0,V+1)]
               for x2 in range(0,V+1)]
              for x3 in range(0,T+1)]
             for x4 in range(0,T+1)]
    SIGMA_SB =  [[[[0
                for x1 in range(0,V+1)]
               for x2 in range(0,V+1)]
              for x3 in range(0,T+1)]
             for x4 in range(0,T+1)]
    EPSILON_SB =  [[[[0
                for x1 in range(0,V+1)]
               for x2 in range(0,V+1)]
              for x3 in range(0,T+1)]
             for x4 in range(0,T+1)]
    PHI_AB =  [[[['A'
                for x1 in range(0,V+1)]
               for x2 in range(0,V+1)]
              for x3 in range(0,T+1)]
             for x4 in range(0,T+1)]
    KAPPA_AB =  [[[['A'
                for x1 in range(0,V+1)]
               for x2 in range(0,V+1)]
              for x3 in range(0,T+1)]
             for x4 in range(0,T+1)]
    SIGMA_AB =  [[[[0
                for x1 in range(0,V+1)]
               for x2 in range(0,V+1)]
              for x3 in range(0,T+1)]
             for x4 in range(0,T+1)]
    EPSILON_AB =  [[[[0
                for x1 in range(0,V+1)]
               for x2 in range(0,V+1)]
              for x3 in range(0,T+1)]
             for x4 in range(0,T+1)]

    # Fill Values:
    for t in range(1,T+1):
        for v in range(1,V+1):
            DELTA[t-1][t][v-1][v] = lexical.b(sent1[t-1],sent2[v-1])

    for t in range(1,T+1):
        for v in range(0,V+1):
            DELTA[t-1][t][v][v] = grammar.wordEpsilon

    for t in range(0,T+1):
        for v in range(1,V+1):
            DELTA[t][t][v-1][v] = grammar.epsilonWord

    for s in range(0,T):
        for t in range(s+1,T+1):
            for u in range(0,V):
                for v in range(u+1,V+1):
                    if (t-s+v-u) > 2:
                        deltaFunc(s,t,u,v,grammar)

    # Reconstructing sentences
    q1 = (0,T,0,V)
    stack1 = [] # stack of NODES
    stack2 = [] # stack for status
    stackc = [] # stack for balanced paranthesis
    parseString = ''
    stack1.append(q1)
    stack2.append(0)

    while len(stack1) > 0: # if NODES stack is not empty
        q = stack1[-1]
        stat = stack2[-1]

        lq = left(q[0],q[1],q[2],q[3])
        rq = right(q[0],q[1],q[2],q[3])

        if stat == 0: # Unvisited Left Child exists
            stack2.pop()
            stack2.append(1)
            if not lq is None:
                stack1.append(lq)
                stack2.append(0)

            if (not lq is None) and (not rq is None):
                if THETA[q[0]][q[1]][q[2]][q[3]] == 's':
                    parseString = parseString + '['
                    stackc.append(']')
                    countSB = countSB + 1
                else:
                    parseString = parseString + '<'
                    stackc.append('>')
                    countAB = countAB + 1

        elif stat == 1: # Unvisited Right Child exists
            stack2.pop()
            stack2.append(2)
            if not rq is None:
                stack1.append(rq)
                stack2.append(0)

        elif stat == 2: # Child NODES have been visited
            if (not lq is None) and (not rq is None): # Leaf Node
                parseString = parseString + stackc.pop()
            else:                                     # Not a Leaf Node
                if q[1] - q[0] == 1:
                    w1 = sent1[q[0]]
                else:
                    w1 = '<e>'
                    countEToWord = countEToWord + 1

                if q[3] - q[2] == 1:
                    w2 = sent2[q[2]]
                else:
                    w2 = '<e>'
                    countWordToE = countWordToE + 1

                parseString = parseString + w1 + '/' + w2 + ' '
                countWordToWord = countWordToWord + 1

            stack1.pop()
            stack2.pop()

    print parseString

def checkExist(ns,n):
    for en in ns:
        eql = True
        for i in range(0,len(en)):
            if n[i] != en[i]:
                eql = False
                break
        if eql:
            return True

deltaStack = []

def deltaFunc(s,t,u,v,grammar):
    global DELTA
    global THETA
    global PHI_SB
    global KAPPA_SB
    global SIGMA_SB
    global EPSILON_SB
    global PHI_AB
    global KAPPA_AB
    global SIGMA_AB
    global EPSILON_AB
    global deltaStack
    if DELTA[s][t][u][v] is None:
        deltaStack.append([s,t,u,v])

    while len(deltaStack) > 0:
        q = deltaStack[-1]
        if updateDelta(q[0],q[1],q[2],q[3],grammar) == True:
            deltaStack.pop()

def updateDelta(s,t,u,v,grammar):
    global DELTA
    global THETA
    global PHI_SB
    global KAPPA_SB
    global SIGMA_SB
    global EPSILON_SB
    global PHI_AB
    global KAPPA_AB
    global SIGMA_AB
    global EPSILON_AB
    global deltaStack

    dsbab = deltaSBAB(s,t,u,v,grammar)
    if dsbab is None:
        return False

    dsb = dsbab[0]
    dab = dsbab[1]
    if dsb >= dab:
        DELTA[s][t][u][v] = dsb
        THETA[s][t][u][v] = 's'
    else:
        DELTA[s][t][u][v] = dab
        THETA[s][t][u][v] = 'a'

    return True

def deltaSBAB(s,t,u,v,grammar):
    global DELTA
    global THETA
    global PHI_SB
    global KAPPA_SB
    global SIGMA_SB
    global EPSILON_SB
    global PHI_AB
    global KAPPA_AB
    global SIGMA_AB
    global EPSILON_AB
    global deltaStack

    posSBMAX = float('-inf')
    sSBMAX = float('-inf')
    uSBMAX = float('-inf')
    posABMAX = float('-inf')
    sABMAX = float('-inf')
    uABMAX = float('-inf')
    for S in range(s,t+1):
        for U in range(u,v+1):
            if not (S-s)*(t-S) + (U-u)*(v-U) == 0:
                delVal1 = DELTA[s][S][u][U]
                delVal2 = DELTA[S][t][U][v]
                delVal3 = DELTA[s][S][U][v]
                delVal4 = DELTA[S][t][u][U]

                if delVal1 is None and not checkExist(deltaStack,[s,S,u,U]):
                    deltaStack.append([s,S,u,U])

                if delVal2 is None and not checkExist(deltaStack,[S,t,U,v]):
                    deltaStack.append([S,t,U,v])

                if delVal3 is None and not checkExist(deltaStack,[s,S,U,v]):
                    deltaStack.append([s,S,U,v])

                if delVal4 is None and not checkExist(deltaStack,[S,t,u,U]):
                    deltaStack.append([S,t,u,U])

                if delVal1 is None or delVal2 is None or delVal3 is None or delVal4 is None:
                    return None

                tempSB = grammar.aToSb + delVal1 + delVal2
                if tempSB >= posSBMAX:
                    posSBMAX = tempSB
                    sSBMAX = S
                    uSBMAX = U
                tempAB = grammar.aToAb + delVal3 + delVal4
                if tempAB >= posABMAX:
                    posABMAX = tempAB
                    sABMAX = S
                    uABMAX = U

    SIGMA_SB[s][t][u][v] = sSBMAX
    EPSILON_SB[s][t][u][v] = uSBMAX
    SIGMA_AB[s][t][u][v] = sABMAX
    EPSILON_AB[s][t][u][v] = uABMAX
    return (posSBMAX,posABMAX)

# Left Node
def left(s,t,u,v):
    if THETA[s][t][u][v] == 's':
        return (s,SIGMA_SB[s][t][u][v],u,EPSILON_SB[s][t][u][v])
    if THETA[s][t][u][v] == 'a':
        return (s,SIGMA_AB[s][t][u][v],EPSILON_AB[s][t][u][v],v)
    return None

# Right Node
def right(s,t,u,v):
    if THETA[s][t][u][v] == 's':
        return (SIGMA_SB[s][t][u][v],t,EPSILON_SB[s][t][u][v],v)
    if THETA[s][t][u][v] == 'a':
        return (SIGMA_AB[s][t][u][v],t,u,EPSILON_AB[s][t][u][v])
    return None

lines = None
sentence1 = None
sentence2 = None

if __name__ == "__main__":
    dicpath = "itg.dict"
    f = open(dicpath)
    lines =  f.readlines()
    f.close()
    lexical = LexicalDictionary(lines)
    grammar1 = BTGGrammar(-1,-2,-20,-21)            # Swap Rule Grammar
    grammar2 = BTGGrammar(-1,float('-inf'),-20,-21) # Monotonic Rule Grammar
    englishPath = "test.en"
    germanPath = "test.de"
    # For Swap Alignment Rule, Uncomment the following line & Comment the Monotonic Rule following line.
    grammar = grammar1
    # For Monotonic Alignment Rule, Uncomment the following line & Comment the above line.
    # grammar = grammar2
    f = open(englishPath)
    inputSent1 = f.readlines()
    f.close()
    f = open(germanPath)
    inputSent2 = f.readlines()
    f.close()
    totalW1 = 0
    totalW2 = 0
    for i in range(0,len(inputSent1)):
        sentence1 = inputSent1[i][:-1].split(' ')
        sentence2 = inputSent2[i][:-1].split(' ')
        totalW1 = totalW1 + len(sentence1)
        totalW2 = totalW2 + len(sentence2)
        parse(sentence1,sentence2,grammar,lexical)

    print 'Count of []:', countSB
    print 'Count of <>:', countAB
    print 'Count of Word to <e> alignment:', countWordToE
    print 'Count of <e> to Word alignment:', countEToWord
    print 'Count of Word 1:', totalW1
    print 'Count of Word 2:', totalW2
    print 'Percentage of Word to <e> alignment:=',countWordToE,'/',totalW1,'=', (float(countWordToE)/float(totalW1)) * 100, '%'
    print 'Percentage of <e> to Word alignment:=',countEToWord,'/',totalW2 ,'=', (float(countEToWord)/float(totalW2)) * 100, '%'