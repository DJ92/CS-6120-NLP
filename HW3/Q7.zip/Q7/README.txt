Steps to Execute:

1. Unzip the package
2. Import the DJ_Parser.py file into PyCharm or run from the Python Shell
3. Make sure test.en, test.de and itg.dict are in the same directory as the Python file.
4. Check the code for Monotonic and Swap Rule Execution changes.

In case of any issues with execution, let me know.
PS: The Output from the console has been provided for verification.