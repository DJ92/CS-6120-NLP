__author__ = 'DJ'
import os
import re
import sys


regpn = re.compile("[A-Z][a-z]+[ ]*")
regids = re.compile("([\w\-\.]+@(\w[\w\-]+\.)+[\w\-]+)")
regstems = re.compile("^(.*?)(ing|ly|ed|ious|ies|ive|es|s|ment)$")
regnum = re.compile("(\d+)")
regprice = re.compile("\$[0-9.,]+")

dirName = os.getcwd() + "/gutenberg/"
dirFileList = os.listdir(dirName)

pronouns = dict()
pnset = set()
pnlist = []

emailids = dict()
idset = set()
idlist = []

stems = dict()
stemset = set()
stemlist = []

nums = dict()
numset = set()
numlist = []

prices = dict()
priceset = set()
pricelist = []

for filename in dirFileList:
    file = open(dirName + filename,'r')
    for line in file.xreadlines():
        words = line.split(" ")
        for w in words:
            pnlist.extend(regpn.findall(w))
            idlist.extend(regids.findall(w))
            stemlist.extend(regstems.findall(w))
            numlist.extend(regnum.findall(w))
            pricelist.extend(regprice.findall(w))

for n in pnlist:
    if len(n) >= 1 and n != '\n':
        pnset.add(n)
pronouns["pronouns"] = pnset

the_filename = "Pronouns.csv"
with open(the_filename, 'w') as f:
    f.write("Pronouns" + '\n')
    for k in pronouns["pronouns"]:
        f.write(str(k)+'\n')

for n in idlist:
    if len(n) >= 1 and n != '\n':
        idset.add(n[0])
emailids["ids"] = idset

the_filename = "EmailIDs.csv"
with open(the_filename, 'w') as f:
    f.write("Email Ids" + '\n')
    for k in emailids["ids"]:
        f.write(str(k)+'\n')

for n in stemlist:
    if len(n) >= 1 and n != '\n':
        stemset.add(n[0]+n[1])
stems["stem"] = stemset

the_filename = "Stems.csv"
with open(the_filename, 'w') as f:
    f.write("Stems" + '\n')
    for k in stems["stem"]:
        f.write(str(k)+'\n')

for n in numlist:
    if len(n) >= 1 and n != '\n':
        numset.add(n)
nums["numbers"] = numset

the_filename = "Numbers.csv"
with open(the_filename, 'w') as f:
    f.write("Numbers" + '\n')
    for k in nums["numbers"]:
        f.write(str(k)+'\n')

for n in pricelist:
    if len(n) >= 1 and n != '\n':
        priceset.add(n)
prices["price"] = priceset

the_filename = "Prices.csv"
with open(the_filename, 'w') as f:
    f.write("Prices" + '\n')
    for k in prices["price"]:
        f.write(str(k)+'\n')
