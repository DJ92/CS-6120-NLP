__author__ = 'DJ'
import re
import sys
import copy
import os

#if sys.argv[1] == '-h':
#    print 'usage:', sys.argv[0], 'regex files...'

regpn = re.compile("[A-Z][a-z]+[ ]*")
regids = re.compile("([\w\-\.]+@(\w[\w\-]+\.)+[\w\-]+)")
regstems = re.compile("^(.*?)(ing|ly|ed|ious|ies|ive|es|s|ment)$")
regnum = re.compile("(\d+)")
regprice = re.compile("\$[0-9.,]+")

dirName = os.getcwd() + "/gutenberg/"
dirFileList = os.listdir(dirName)

pnset = set()
pnlist = []

idset = set()
idlist = []

stemset = set()
stemlist = []

numset = set()
numlist = []

priceset = set()
pricelist = []

for filename in dirFileList:
    file = open(dirName + filename,'r')
    for line in file.xreadlines():
        words = line.split(" ")
        for w in words:
            pnlist.extend(regpn.findall(w))
            idlist.extend(regids.findall(w))
            stemlist.extend(regstems.findall(w))
            numlist.extend(regnum.findall(w))
            pricelist.extend(regprice.findall(w))

for n in pnlist:
    if len(n) >= 1 and n != '\n':
        pnset.add(n)
print "Pronouns: ",len(pnset)

for n in idlist:
    if len(n) >= 1 and n != '\n':
        idset.add(n)
print "Email Ids: ",len(idset)

for n in stemlist:
    if len(n) >= 1 and n != '\n':
        stemset.add(n)
print "Stems: ",len(stemset)

for n in numlist:
    if len(n) >= 1 and n != '\n':
        numset.add(n)
print "Numbers: ",len(numset)

for n in pricelist:
    if len(n) >= 1 and n != '\n':
        priceset.add(n)
print "Prices: ",len(priceset)


